import { URLBD } from '../utils/utils.js';

let config = {
    headers:new Headers({
        "Content-Type": "application/json"
    }), 
};


const getFetch = async(url)=>{
    config.method = "GET";
    let res = await ( await fetch(`${URLBD}/${url}`,config)).json();
    return res;
}
const getForIdFetch = async(url, id)=>{
    config.method = "GET";
    let res = await ( await fetch(`${URLBD}/${url}/${id}`,config)).json();
    return res;
}
const searchFetch = async(url, query)=>{
    config.method = "GET";
    let res = await ( await fetch(`${URLBD}/${url}?q=${query}`,config)).json();
    return res;
}
const searchExactFetch = async(url, query, property)=>{
    config.method = "GET";
    let res = await ( await fetch(`${URLBD}/${url}?${property}=${query}`,config)).json();
    return res;
}
const searchExactRutasFetch = async(origen, destino)=>{
    config.method = "GET";
    let res = await ( await fetch(`${URLBD}/rutas?origen=${origen}&destino=${destino}`,config)).json();
    return res;
}
const deleteFetch = async(url, id)=>{
    config.method = "DELETE";
    let res = await fetch(`${URLBD}/${url}/${id}`,config)
    return res;
}
const postFetch = async(url, data)=>{
    config.method = "POST";
    config.body = JSON.stringify(data);
    let res = await fetch(`${URLBD}/${url}`,config)
    return res;
}
const putFetch = async(url, id, data)=>{
    config.method = "PUT";
    config.body = JSON.stringify(data);
    let res = await fetch(`${URLBD}/${url}/${id}`,config)
    return res;
}
export { getFetch, postFetch, putFetch, deleteFetch, searchFetch, searchExactFetch, getForIdFetch, searchExactRutasFetch};