const PUERTOBD = 4001;
const URLBD = `http://localhost:${PUERTOBD}`;
export { URLBD };