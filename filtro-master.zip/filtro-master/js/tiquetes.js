import {searchExactFetch, getFetch, searchExactRutasFetch, postFetch} from '../utils/methodFetch.js';

let dataTiquete = {}
let ciudades = [];
let rutas = [];
let rutaSeleccionada = {};

let buscaridentificacion = document.querySelector("#buscarIdentificacion");
buscaridentificacion.addEventListener("submit", async (e) => {
    e.preventDefault();
    let identificacionBuscar = document.querySelector("#identificacionBuscar").value;
    const res = await searchExactFetch("clientes", identificacionBuscar, "identificacion")
    if (res.length <= 0) {
        desbloquearCampos(true, true);
    }else {
        llenadoCampos(res[0]);
    }
});

const llenadoCampos = (data) => {
    desbloquearCampos(false, true);
    let identificacion = document.querySelector("#identificacion");
    let nombre = document.querySelector("#nombre");
    let apellido = document.querySelector("#apellido");
    let email = document.querySelector("#email");
    identificacion.value = data.identificacion;
    nombre.value = data.nombre;
    apellido.value = data.apellido;
    email.value = data.email;
}
const desbloquearCampos = (desbloquear, borrar) => {
    const inputDisabled = document.querySelectorAll(".input-disabled");
    inputDisabled.forEach(input => {
        input.disabled = !desbloquear;
        if (borrar) input.value = "";
    });
}

const comprarTiquete = document.querySelector("#comprarTiquete");
comprarTiquete.addEventListener("submit", async (e) => {
    e.preventDefault();
    desbloquearCampos(true, false);
    let data = Object.fromEntries(new FormData(e.target));
    dataTiquete = data;
    desbloquearCampos(false, false);
    console.log(data)
    let origen=data.origen, destino = data.destino;
    // hacer funcion que encuentre la ruta
    encontrarRuta(origen, destino);
});

const encontrarRuta = async (origen, destino) => {
    const res = await searchExactRutasFetch(origen, destino);
    if (res.length <= 0) {
        alert("No hay rutas disponibles");
    }else {
        rutas = res;
        mostrarRutas();
    }
};

const mostrarRutas = () => {
    let selectRuta = document.querySelector("#selectRuta");
    selectRuta.innerHTML = "";
    rutas.forEach(ruta => {
        let str = `
            <option value="${ruta.nombreRuta}">${ruta.nombreRuta}</option>
        `
        selectRuta.insertAdjacentHTML("beforeend", str);
    });
    
};

const mostrarCiudades= async () => {
    const res = await getFetch("ciudades")
    ciudades = res;
    const selectOrigen = document.querySelector("#origen");
    const selectDestino = document.querySelector("#destino");
    res.forEach(ciudad => {
        let str = `
            <option value="${ciudad.nombre}">${ciudad.nombre}</option>
        `
        selectOrigen.insertAdjacentHTML("beforeend", str);
        selectDestino.insertAdjacentHTML("beforeend", str);
    });
}

let formRutaSelect = document.querySelector("#formRutaSelect");
formRutaSelect.addEventListener("submit", (e) => {
    e.preventDefault();
    let ruta = document.querySelector("#selectRuta").value;
    rutaSeleccionada = rutas.find(r => r.nombreRuta == ruta);
    mostrarResumenCompra();
});

const mostrarResumenCompra = () => {
    let resumenCompra = document.querySelector("#resumenCompra");
    let modalContent = document.querySelector("#modal-content");
    modalContent.innerHTML = "";
    resumenCompra.innerHTML = "";
    let valor = parseFloat(rutaSeleccionada.valor);
    let subTotal = valor + (valor * 0.05);
    let valorTotal = subTotal + (subTotal * 0.16);
    rutaSeleccionada.valorTotal = valorTotal;
    dataTiquete.ruta = rutaSeleccionada
    let str = `
        <p>Origen: ${rutaSeleccionada.origen}</p>
        <p>Destino: ${rutaSeleccionada.destino}</p>
        <p>Millas : ${rutaSeleccionada.millas}</p>
        <p>Nombre ruta: ${rutaSeleccionada.nombreRuta}</p>
        <p>Valor: ${valor}</p>
        <p>Valor total: ${valorTotal}</p>
    `
    resumenCompra.insertAdjacentHTML("beforeend", str);
    modalContent.insertAdjacentHTML("beforeend", str);
}
let comprarTiqueteBtn = document.querySelector("#comprarTiqueteBtn");
const comprarTiqueteFn = async () => {
    const res = await postFetch("tiquetes", dataTiquete)
    console.log(res)
    if (res.status == 201) {
        modal()
        alert("Tiquete comprado");
        window.location.reload();
    }else {
        alert("Error al comprar tiquete");
        console.log(res)
    }
 }
comprarTiqueteBtn.addEventListener("click", comprarTiqueteFn);

let cancelarTiqueteBtn = document.querySelector("#cancelarTiqueteBtn");
const cancelarTiqueteFn = () => window.location.reload()
cancelarTiqueteBtn.addEventListener("click", cancelarTiqueteFn);


const modal= () => {
    let modal = document.getElementById("myModal");
    let span = document.getElementsByClassName("close")[0];
    modal.style.display = "block";
    span.onclick = function() {
    modal.style.display = "none";
    }
    window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
    } 
}


mostrarCiudades()