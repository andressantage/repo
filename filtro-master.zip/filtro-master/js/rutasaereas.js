import { postFetch, searchExactFetch } from "../utils/methodFetch.js";

const formRutas = document.querySelector("#formRutas");
formRutas.addEventListener("submit", async (e) => {
    e.preventDefault();
    let data = Object.fromEntries(new FormData(e.target));
    if (data.origen == data.destino) return alert("El origen y el destino no pueden ser iguales");
    const res1 = await searchExactFetch("ciudades", data.origen, "nombre")
    const res2 = await searchExactFetch("ciudades", data.destino, "nombre")
    if (res1.length <=0) {
        await postFetch("ciudades", {nombre:data.origen});
    }
    if (res2.length <=0) {
        await postFetch("ciudades", {nombre:data.destino});
    }
    let res = await postFetch("rutas", data);
    if (res.status == 200) {
        alert("Ruta creada correctamente");
        formRutas.reset();
    }else {
        alert("Error al crear la ruta");
        console.log(res);
    }
});