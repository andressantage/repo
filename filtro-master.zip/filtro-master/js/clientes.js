import { searchFetch, getForIdFetch, putFetch, deleteFetch, postFetch } from '../utils/methodFetch.js';

const inputSearch = document.querySelector('#input-search');
inputSearch.value = "";
inputSearch.addEventListener('keyup', e=>{
    let valueSearch = e.target.value.trim();
    opc["SEARCH"](valueSearch);
})
const opc = {
    "SEARCH": (data)=>searchInput(data),
};

const searchInput = async (query)=>{
    let tableSearchTbody = document.querySelector('#table-search-tbody');
    tableSearchTbody.innerHTML = "";
    if (query.length <= 0) return;
    const res = await searchFetch("clientes", query);
    if (res.length <= 0) {
        tableSearchTbody.innerHTML = `
        <tr>
            <td colspan="4">No se encontraron resultados</td>
        </tr>
        `
    };
    res.forEach(cliente => {
        let str =`
        <tr>
            <td>${cliente.identificacion}</td>
            <td>${cliente.nombre}</td>
            <td>${cliente.apellido}</td>
            <td>
            <button id="btnSearch-${cliente.id}" class="btnSeleccionar">Seleccionar</button>
            </td>
        </tr>
        `
        tableSearchTbody.insertAdjacentHTML('beforeend', str);
    });
    addEventBtn()
}
const addEventBtn = async () =>{
    let btnSeleccionar = document.querySelectorAll('.btnSeleccionar');
    btnSeleccionar.forEach(btn=>{
        btn.addEventListener('click', e=>{
            selectCliente(e.target.id.split('-')[1]);
        })
})}
const selectCliente = async (id)=>{
    const cliente = await getForIdFetch("clientes", id)
    const tableSelectClientTbody = document.querySelector("#table-selectClient-tbdoy");
    tableSelectClientTbody.innerHTML = "";
    let str = `
    <tr id="tr-select-${cliente.id}">
        <td><input type="text" class="input-client" name="identificacion" disabled value="${cliente.identificacion}"></td>
        <td><input type="text" class="input-client" name="nombre" disabled value="${cliente.nombre}"></td>
        <td><input type="text" class="input-client" name="apellido" disabled value="${cliente.apellido}"></td>
        <td><input type="text" class="input-client" name="telefono" disabled value="${cliente.telefono}"></td>
        <td><input type="date" class="input-client" name="fechaNacimiento" disabled value="${cliente.fechaNacimiento}"></td>
        <td><input type="text" class="input-client" name="ciudadOrigen" disabled value="${cliente.ciudadOrigen}"></td>
        <td><input type="text" class="input-client" name="paisOrigen" disabled value="${cliente.paisOrigen}"></td>
        <td><input type="email" class="input-client" name="email" disabled value="${cliente.email}"></td>
        <td>
            <div id="div-client-acciones">
                <button id="btnEdit-${cliente.id}" class="btnAccClient">Editar</button>
                <button id="btnDelete-${cliente.id}" class="btnAccClient">Eliminar</button>
            </div>
        </td>
    </tr>
    `
    tableSelectClientTbody.insertAdjacentHTML('beforeend', str);
    btnAciones();
}
const btnAciones = ()=>{
    const btnAccClient = document.querySelectorAll('.btnAccClient');
    btnAccClient.forEach(btn=>{
        btn.addEventListener('click', e=>{
            let id = e.target.id.split('-')[1];
            if (e.target.textContent == "Editar") {
                editCliente(id);
            }else{
                deleteCliente(id);
            }
        })
    })
}
const editCliente = async (id)=>{
    const inputs = document.querySelectorAll('.input-client');
    inputs.forEach(input=>{
        input.disabled = false;
    })
    const divClientAcciones = document.querySelector("#div-client-acciones")
    divClientAcciones.innerHTML = "";
    let str = `
    <button id="btnUpdate-${id}" class="btnAccClient2">Actualizar</button>
    <button id="btnCancel-${id}" class="btnAccClient2">Cancelar</button>
    `
    divClientAcciones.insertAdjacentHTML('beforeend', str);
    const btnAccClient2 = document.querySelectorAll('.btnAccClient2');
    btnAccClient2.forEach(btn=>{
        btn.addEventListener('click', e=>{
            let id = e.target.id.split('-')[1];
            if (e.target.textContent == "Actualizar") {
                updateCliente(id);
            }else{
                cancelCliente(id);
            }
        })
    })
}
const deleteCliente = async (id)=>{
    const res = await deleteFetch("clientes", id);
    if (res.ok) {
        const tr = document.querySelector(`#tr-select-${id}`);
        tr.remove();
        window.location.reload();
    }
}
const updateCliente = async (id)=>{
    const inputs = document.querySelectorAll('.input-client');
    let data = {};
    inputs.forEach(input=>{
        data[input.name] = input.value;
    })
    const res = await putFetch("clientes", id, data);
    if (res.ok) {
        window.location.reload();
    }
}
const cancelCliente = async (id)=>{
    window.location.reload();
}
const formCreatedClient = document.querySelector('#formCreatedClient');
formCreatedClient.addEventListener('submit', async e =>{
    e.preventDefault();
    let data = Object.fromEntries(new FormData(e.target));
    const res = await postFetch("clientes", data);
    if (res.ok) {
        alert("Cliente creado correctamente");
        formCreatedClient.reset();
    }else{
        alert("Error al crear el cliente");
        formCreatedClient.reset();
    }
})
